﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;
namespace MiniPaint
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            g = pnl_Draw.CreateGraphics();
            x = 0;
            y = 0;
        }
        bool startPaint = false;
        Graphics g;
        //nullable int for storing Null value
        int? initX = null;
        int? initY = null;
        int x, y;
        public bool drawSquare = false ;
        public bool drawRectangle = false;
        public bool drawCircle = false;
        public void raw(MouseEventArgs e, float size)
        {


            int x = e.X;
            int y = e.Y;
            x= this.Height - (x - 111); // tạo đối xứng 
                
            Pen p = new Pen(btn_PenColor.BackColor,size);// tạo màu 
            g.DrawLine(p, new Point(initX ?? x, initY ?? y), new Point(x, y)); // vẽ 1 đoạn thẳng 
            initX = x; // lưu lại x bước trước
            initY = y; // lưu lại y bước trước
               
            
            
        }
        //Event Fired when the mouse pointer is over Panel and a mouse button is pressed
   
        //Fired when the mouse pointer is over the pnl_Draw and a mouse button is released.
        private void pnl_Draw_MouseUp(object sender, MouseEventArgs e)
        {
            startPaint = false;
            initX = null;
            initY = null;
        }
        //Button for Setting pen Color
        public void  reset()
        {
            startPaint = false;
            initX = null;
            initY = null;
        }
        public  void doiMau(Color x)
        {
            
                btn_PenColor.BackColor = x;
            
        }
      
        //Setting the Canvas Color
        public void raw_background(Color c)
        {
            pnl_Draw.BackColor = c;
            btn_CanvasColor.BackColor = c;
            
        }
        private void btn_CanvasColor_Click_1(object sender, EventArgs e)
        {
            ColorDialog c = new ColorDialog();
            if (c.ShowDialog() == DialogResult.OK)
            {
                pnl_Draw.BackColor = c.Color;
                btn_CanvasColor.BackColor = c.Color;
              
            }

        }

        private void btn_Square_Click(object sender, EventArgs e)
        {
            drawSquare = true;
   
        }

        private void btn_Rectangle_Click(object sender, EventArgs e)
        {
            drawRectangle = true;

        }

        private void btn_Circle_Click(object sender, EventArgs e)
        {
            drawCircle = true;
        }
        public void pnl_Draw_hinh(MouseEventArgs e, int size)
        {
            int X = this.Height - (e.X-111);
            int Y = e.Y;
            if (drawSquare)
            {
                //Use Solid Brush for filling the graphic shapes
                SolidBrush sb = new SolidBrush(btn_PenColor.BackColor);
                //setting the width and height same for creating square.
                //Getting the width and Heigt value from Textbox(txt_ShapeSize)
                g.FillRectangle(sb, X-size, Y, size, size);
                //setting startPaint and drawSquare value to false for creating one graphic on one click.
                startPaint = false;
                drawSquare = false;
            }
            if (drawRectangle)
            {
                SolidBrush sb = new SolidBrush(btn_PenColor.BackColor);
                //setting the width twice of the height
                g.FillRectangle(sb, X-2*size, Y, 2 * size, size);
                startPaint = false;
                drawRectangle = false;
            }
            if (drawCircle)
            {
                SolidBrush sb = new SolidBrush(btn_PenColor.BackColor);
                g.FillEllipse(sb, X, Y, size, size);
                startPaint = false;
                drawCircle = false;
            }
        }
        private void pnl_Draw_MouseDown(object sender, MouseEventArgs e)
        {

            startPaint = true;

            if (drawSquare)
            {
                //Use Solid Brush for filling the graphic shapes
                SolidBrush sb = new SolidBrush(btn_PenColor.BackColor);
                //setting the width and height same for creating square.
                //Getting the width and Heigt value from Textbox(txt_ShapeSize)
                g.FillRectangle(sb, e.X, e.Y, int.Parse(txt_ShapeSize.Text), int.Parse(txt_ShapeSize.Text));
                //setting startPaint and drawSquare value to false for creating one graphic on one click.
                startPaint = false;
                drawSquare = false;
            }
            if (drawRectangle)
            {
                SolidBrush sb = new SolidBrush(btn_PenColor.BackColor);
                //setting the width twice of the height
                g.FillRectangle(sb, e.X, e.Y, 2 * int.Parse(txt_ShapeSize.Text), int.Parse(txt_ShapeSize.Text));
                startPaint = false;
                drawRectangle = false;
            }
            if (drawCircle)
            {
                SolidBrush sb = new SolidBrush(btn_PenColor.BackColor);
                g.FillEllipse(sb, e.X, e.Y, int.Parse(txt_ShapeSize.Text), int.Parse(txt_ShapeSize.Text));
                startPaint = false;
                drawCircle = false;
            }
        }

        //New 
        public void newFile()
        {

            //Clearing the graphics from the Panel(pnl_Draw)
            g.Clear(pnl_Draw.BackColor);
            //Setting the BackColor of pnl_draw and btn_CanvasColor to White on Clicking New under File Menu
            pnl_Draw.BackColor = Color.White;
            btn_CanvasColor.BackColor = Color.White;

        }
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Clearing the graphics from the Panel(pnl_Draw)
            g.Clear(pnl_Draw.BackColor);
            //Setting the BackColor of pnl_draw and btn_CanvasColor to White on Clicking New under File Menu
            pnl_Draw.BackColor = Color.White;
            btn_CanvasColor.BackColor = Color.White;
        }
        //Setting the Canvas Color
        private void button1_Click(object sender, EventArgs e)
        {
            ColorDialog c = new ColorDialog();
            if (c.ShowDialog() == DialogResult.OK)
            {
                btn_PenColor.BackColor = c.Color;
               
            }

        }

        public void exit()
        {
            
           // Application.Exit();
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to Exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

      
        private void aboutMiniPaintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About a = new About();
            a.ShowDialog();
        }

    }



    public partial class Form2 : Form
    {


        private Thread ve; // luống của cửa sổ mới 
        public Form2()
        { 
            InitializeComponent();
            Control.CheckForIllegalCrossThreadCalls = false;// Tắt kiểm tra luống để bắt sự kiện
            g = pnl_Draw.CreateGraphics(); // tạo luồng vẽ  
            ve = new Thread(new ThreadStart(tt)); // khai báo khung mới
            ve.Start();  

        }
        bool startPaint = false;
        Graphics g;
        Form1 l1 = new Form1();
        //nullable int for storing Null value
        int? initX = null;
        int? initY = null;
        bool drawSquare = false;
        bool drawRectangle = false;
        bool drawCircle = false;
        //Event fired when the mouse pointer is moved over the Panel(pnl_Draw).
        private void pnl_Draw_MouseMove(object sender, MouseEventArgs e)
        {
            
                // do the work here
                if (startPaint)
                {
                      raw(e.X, e.Y);
                  //  l1.update(e.X, e.Y);
                    l1.raw(e, float.Parse(cmb_PenSize.Text));
                }


        }
        public void raw(int x, int y)
        {
            Pen p = new Pen(btn_PenColor.BackColor, float.Parse(cmb_PenSize.Text));
            g.DrawLine(p, new Point(initX ?? x, initY ?? y), new Point(x, y));
 
            initX = x;
            initY = y;
        }
        //Event Fired when the mouse pointer is over Panel and a mouse button is pressed
        private void pnl_Draw_MouseDown(object sender, MouseEventArgs e)
        {
          
                startPaint = true;

                if (drawSquare)
                {
                    //Use Solid Brush for filling the graphic shapes
                    SolidBrush sb = new SolidBrush(btn_PenColor.BackColor);
                    //setting the width and height same for creating square.
                    //Getting the width and Heigt value from Textbox(txt_ShapeSize)
                    g.FillRectangle(sb, e.X, e.Y, int.Parse(txt_ShapeSize.Text), int.Parse(txt_ShapeSize.Text));
                    //setting startPaint and drawSquare value to false for creating one graphic on one click.
                    startPaint = false;
                    drawSquare = false;
                }
                if (drawRectangle)
                {
                    SolidBrush sb = new SolidBrush(btn_PenColor.BackColor);
                    //setting the width twice of the height
                    g.FillRectangle(sb, e.X, e.Y, 2 * int.Parse(txt_ShapeSize.Text), int.Parse(txt_ShapeSize.Text));
                    startPaint = false;
                    drawRectangle = false;
                }
                if (drawCircle)
                {
                    SolidBrush sb = new SolidBrush(btn_PenColor.BackColor);
                    g.FillEllipse(sb, e.X, e.Y, int.Parse(txt_ShapeSize.Text), int.Parse(txt_ShapeSize.Text));
                    startPaint = false;
                    drawCircle = false;
                }
                l1.pnl_Draw_hinh(e, int.Parse(txt_ShapeSize.Text));


        }
        //Fired when the mouse pointer is over the pnl_Draw and a mouse button is released.
        private void pnl_Draw_MouseUp(object sender, MouseEventArgs e)
        {

                startPaint = false;
                initX = null;
                initY = null;
               l1.reset();
        }
        //Button for Setting pen Color
        private void button1_Click(object sender, EventArgs e)
        {
            //Open Color Dialog and Set BackColor of btn_PenColor if user click on OK
            
                ColorDialog c = new ColorDialog();
                if (c.ShowDialog() == DialogResult.OK)
                {
                    btn_PenColor.BackColor = c.Color;
                   l1.doiMau(c.Color);
                }
          
        }
        //New 
        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            //Clearing the graphics from the Panel(pnl_Draw)
            g.Clear(pnl_Draw.BackColor);
            //Setting the BackColor of pnl_draw and btn_CanvasColor to White on Clicking New under File Menu
            pnl_Draw.BackColor = Color.White;
            btn_CanvasColor.BackColor = Color.White;
            l1.newFile();
           
        }
       
        //Setting the Canvas Color
        private void btn_CanvasColor_Click_1(object sender, EventArgs e)
        {
          ColorDialog c = new ColorDialog();
                if (c.ShowDialog() == DialogResult.OK)
                {
                    pnl_Draw.BackColor = c.Color;
                    btn_CanvasColor.BackColor = c.Color;
                    l1.raw_background(c.Color);
                }
           
        }

        private void btn_Square_Click(object sender, EventArgs e)
        {
            drawSquare = true;
            l1.drawSquare = true;


        }

        private void btn_Rectangle_Click(object sender, EventArgs e)
        {
            drawRectangle = true;
            l1.drawRectangle = true;
        }

        private void btn_Circle_Click(object sender, EventArgs e)
        {
            drawCircle = true;
            l1.drawCircle = true;
        }
        //Exit under File Menu
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to Exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
            {
                l1.exit();
                Application.Exit();
                ve.Abort();         
            }
            
        }
        //About under Help Menu
        private void aboutMiniPaintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
             About a = new About();
             a.ShowDialog();
  
        }

        public void tt()
        {

            Application.Run(l1);
            
        }

    }
}
